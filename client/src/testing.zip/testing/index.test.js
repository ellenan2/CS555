// require('@babel/register')();

// import { describe, expect, it } from '@jest/globals';
// import currentOffersTest from './currentOffersTesting.test.js';
// import ongoingServicesTest from './offersTesting.test.js';
// import userProfileTest from './userProfileTesting.test.js';

// describe('All tests', () => {
//   describe('Current offers', () => {
//     currentOffersTest();
//   });
//   describe('Ongoing services', () => {
//     ongoingServicesTest();
//   });
//   describe('User profile', () => {
//     userProfileTest();
//   });
// });
